package com.autodesk.data.test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.autodesk.data.platform.snow.ServiceNow;

public class ServiceNowClientTest {
	
	private String yetiAppKey;
	private String yetiApiKey;
	private String snowNotificationGroup;

	@Before
	public void setUp() throws Exception {
		yetiAppKey = "<APP KEY>";
		yetiApiKey = "<API KEY>";
		snowNotificationGroup = "ADP-STG-Ingest-Lambda";
	}

	@After
	public void tearDown() throws Exception {
		yetiAppKey = null;
		yetiApiKey = null;
		snowNotificationGroup = null;
	}

	@Test
	public void test() {
		ServiceNow serviceNow = new ServiceNow(yetiAppKey, yetiApiKey);
		String status = "critical";
		String host = "Pelican Finance Report Ingestion";
		String rootCause = "Vault Exception in Pelican Finance Report ingestion - 09112017";
		String shortDescription = "root cause --> com.bettercloud.vault.VaultException: com.bettercloud.vault.rest.RestException";
		String severity = "3";
		String partitionKey = " ADP-Ingest";
		String description = "ConnectException: Connection timed out";
		boolean serviceStatus = serviceNow.generateServiceNowAlert(status, host, rootCause, shortDescription, snowNotificationGroup, severity, partitionKey, description);
		System.out.println("Status: " + serviceStatus);
		assert(serviceStatus);
	}
}
