package com.autodesk.data.stream.dto;

import com.autodesk.data.util.DateFormatUtil;
import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.opencsv.bean.CsvBind;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FinanceReport {
	
	@CsvBind
	private String orderNo;
	@CsvBind
	private String transactionId;
	@CsvBind
	private String orderDate;
	@CsvBind
	private String customerName;
	@CsvBind
	private String o2Id;
	@CsvBind
	private String productLineCode;
	@CsvBind
	private String productId;
	@CsvBind
	private String productName;
	@CsvBind
	private String billingTerm;
	@CsvBind
	private String subscriptionId;
	@CsvBind
	private String quantity;
	@CsvBind
	private String listPrice;
	@CsvBind
	private String totalPrice;
	@CsvBind
	private String creditDaysDiscount;
	@CsvBind
	private String unitDiscount;
	@CsvBind
	private String tax;
	@CsvBind
	private String totalOrderPrice;
	@CsvBind
	private String billToProvince;
	@CsvBind
	private String billToPostalCode;
	@CsvBind
	private String billToCountry;
	@CsvBind
	private String saleType;
	@CsvBind
	private String orderStatus;
	@CsvBind
	private String currency;
	@CsvBind
	private String orderOrigin;
	@CsvBind
	private String offeringType;
	@CsvBind
	private String offeringDetailsName;
	@CsvBind
	private String offeringDetailsExternalKey;
	@CsvBind
	private String supportLevel;
	@CsvBind
	private String mediaType;
	@CsvBind
	private String nextBilling_date;
	@CsvBind
	private String extendedListPrice;
	@CsvBind
	private String extendedTotalDiscount;
	@CsvBind
	private String promoName;
	@CsvBind
	private String promoType;
	@CsvBind
	private String promoSubType;
	@CsvBind
	private String shipToProvince;
	@CsvBind
	private String shipToPostalCode;
	@CsvBind
	private String shipToCountry;
	@CsvBind
	private String paymentType;
	@CsvBind
	private String psp;
	@CsvBind
	private String store;
	@CsvBind
	private String subscriptionPeriodStartDate;
	@CsvBind
	private String subscriptionPeriodEndDate;
	@CsvBind
	private String sapContractStartDate;
	@CsvBind
	private String sapContractEndDate;
	@CsvBind
	private String fulfillmentDate;
	@CsvBind
	private String vatRegistrationId;
	@CsvBind
	private String vatRateApplied;
	@CsvBind
	private String taxCode;
	@CsvBind
	private String invoiceNumber;
	@CsvBind
	private String ipCountry;
	@CsvBind
	private String lastModifiedDate;
	@CsvBind
	private String promoSetupAmount;
	@CsvBind
	private String promoSetupUnit;
	@CsvBind
	private String usageType;
	@CsvBind
	private String subscriptionPlanExternalKey;
	@CsvBind
	private String subscriptionPlanName;
	
	@JsonGetter("ORDER_NO")
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	@JsonGetter("TRANSACTION_ID")
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	@JsonGetter("ORDER_DATE")
	public String getOrderDate() {
		return DateFormatUtil.addOffset(orderDate);
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	@JsonGetter("CUSTOMER_NAME")
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	@JsonGetter("O2_ID")
	public String getO2Id() {
		return o2Id;
	}
	public void setO2Id(String o2Id) {
		this.o2Id = o2Id;
	}
	@JsonGetter("PRODUCT_LINE_CODE")
	public String getProductLineCode() {
		return productLineCode;
	}
	public void setProductLineCode(String productLineCode) {
		this.productLineCode = productLineCode;
	}
	@JsonGetter("PRODUCT_ID")
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	@JsonGetter("PRODUCT_NAME")
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	@JsonGetter("BILLING_TERM")
	public String getBillingTerm() {
		return billingTerm;
	}
	public void setBillingTerm(String billingTerm) {
		this.billingTerm = billingTerm;
	}
	@JsonGetter("SUBSCRIPTION_ID")
	public String getSubscriptionId() {
		return subscriptionId;
	}
	public void setSubscriptionId(String subscriptionId) {
		this.subscriptionId = subscriptionId;
	}
	@JsonGetter("QUANTITY")
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	@JsonGetter("LIST_PRICE")
	public String getListPrice() {
		return listPrice;
	}
	public void setListPrice(String listPrice) {
		this.listPrice = listPrice;
	}
	@JsonGetter("TOTAL_PRICE")
	public String getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(String totalPrice) {
		this.totalPrice = totalPrice;
	}
	@JsonGetter("CREDIT_DAYS_DISCOUNT")
	public String getCreditDaysDiscount() {
		return creditDaysDiscount;
	}
	public void setCreditDaysDiscount(String creditDaysDiscount) {
		this.creditDaysDiscount = creditDaysDiscount;
	}
	@JsonGetter("UNIT_DISCOUNT")
	public String getUnitDiscount() {
		return unitDiscount;
	}
	public void setUnitDiscount(String unitDiscount) {
		this.unitDiscount = unitDiscount;
	}
	@JsonGetter("TAX")
	public String getTax() {
		return tax;
	}
	public void setTax(String tax) {
		this.tax = tax;
	}
	@JsonGetter("TOTAL_ORDER_PRICE")
	public String getTotalOrderPrice() {
		return totalOrderPrice;
	}
	public void setTotalOrderPrice(String totalOrderPrice) {
		this.totalOrderPrice = totalOrderPrice;
	}
	@JsonGetter("BILL_TO_PROVINCE")
	public String getBillToProvince() {
		return billToProvince;
	}
	public void setBillToProvince(String billToProvince) {
		this.billToProvince = billToProvince;
	}
	@JsonGetter("BILL_TO_POSTAL_CODE")
	public String getBillToPostalCode() {
		return billToPostalCode;
	}
	public void setBillToPostalCode(String billToPostalCode) {
		this.billToPostalCode = billToPostalCode;
	}
	@JsonGetter("BILL_TO_COUNTRY")
	public String getBillToCountry() {
		return billToCountry;
	}
	public void setBillToCountry(String billToCountry) {
		this.billToCountry = billToCountry;
	}
	@JsonGetter("SALE_TYPE")
	public String getSaleType() {
		return saleType;
	}
	public void setSaleType(String saleType) {
		this.saleType = saleType;
	}
	@JsonGetter("ORDER_STATUS")
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	@JsonGetter("CURRENCY")
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	@JsonGetter("ORDER_ORIGIN")
	public String getOrderOrigin() {
		return orderOrigin;
	}
	public void setOrderOrigin(String orderOrigin) {
		this.orderOrigin = orderOrigin;
	}
	@JsonGetter("OFFERING_TYPE")
	public String getOfferingType() {
		return offeringType;
	}
	public void setOfferingType(String offeringType) {
		this.offeringType = offeringType;
	}
	@JsonGetter("OFFERING_DETAILS_NAME")
	public String getOfferingDetailsName() {
		return offeringDetailsName;
	}
	public void setOfferingDetailsName(String offeringDetailsName) {
		this.offeringDetailsName = offeringDetailsName;
	}
	@JsonGetter("OFFERING_DETAILS_EXTERNAL_KEY")
	public String getOfferingDetailsExternalKey() {
		return offeringDetailsExternalKey;
	}
	public void setOfferingDetailsExternalKey(String offeringDetailsExternalKey) {
		this.offeringDetailsExternalKey = offeringDetailsExternalKey;
	}
	@JsonGetter("SUPPORT_LEVEL")
	public String getSupportLevel() {
		return supportLevel;
	}
	public void setSupportLevel(String supportLevel) {
		this.supportLevel = supportLevel;
	}
	@JsonGetter("MEDIA_TYPE")
	public String getMediaType() {
		return mediaType;
	}
	public void setMediaType(String mediaType) {
		this.mediaType = mediaType;
	}
	@JsonGetter("NEXT_BILLING_DATE")
	public String getNextBilling_date() {
		return DateFormatUtil.addOffset(nextBilling_date);
	}
	public void setNextBilling_date(String nextBilling_date) {
		this.nextBilling_date = nextBilling_date;
	}
	@JsonGetter("EXTENDED_LIST_PRICE")
	public String getExtendedListPrice() {
		return extendedListPrice;
	}
	public void setExtendedListPrice(String extendedListPrice) {
		this.extendedListPrice = extendedListPrice;
	}
	@JsonGetter("EXTENDED_TOTAL_DISCOUNT")
	public String getExtendedTotalDiscount() {
		return extendedTotalDiscount;
	}
	public void setExtendedTotalDiscount(String extendedTotalDiscount) {
		this.extendedTotalDiscount = extendedTotalDiscount;
	}
	@JsonGetter("PROMO_NAME")
	public String getPromoName() {
		return promoName;
	}
	public void setPromoName(String promoName) {
		this.promoName = promoName;
	}
	@JsonGetter("PROMO_TYPE")
	public String getPromoType() {
		return promoType;
	}
	public void setPromoType(String promoType) {
		this.promoType = promoType;
	}
	@JsonGetter("PROMO_SUB_TYPE")
	public String getPromoSubType() {
		return promoSubType;
	}
	public void setPromoSubType(String promoSubType) {
		this.promoSubType = promoSubType;
	}
	@JsonGetter("SHIP_TO_PROVINCE")
	public String getShipToProvince() {
		return shipToProvince;
	}
	public void setShipToProvince(String shipToProvince) {
		this.shipToProvince = shipToProvince;
	}
	@JsonGetter("SHIP_TO_POSTAL_CODE")
	public String getShipToPostalCode() {
		return shipToPostalCode;
	}
	public void setShipToPostalCode(String shipToPostalCode) {
		this.shipToPostalCode = shipToPostalCode;
	}
	@JsonGetter("SHIP_TO_COUNTRY")
	public String getShipToCountry() {
		return shipToCountry;
	}
	public void setShipToCountry(String shipToCountry) {
		this.shipToCountry = shipToCountry;
	}
	@JsonGetter("PAYMENT_TYPE")
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	@JsonGetter("PSP")
	public String getPsp() {
		return psp;
	}
	public void setPsp(String psp) {
		this.psp = psp;
	}
	@JsonGetter("STORE")
	public String getStore() {
		return store;
	}
	public void setStore(String store) {
		this.store = store;
	}
	@JsonGetter("SUBSCRIPTION_PERIOD_START_DATE")
	public String getSubscriptionPeriodStartDate() {
		return DateFormatUtil.addOffset(subscriptionPeriodStartDate);
	}
	public void setSubscriptionPeriodStartDate(String subscriptionPeriodStartDate) {
		this.subscriptionPeriodStartDate = subscriptionPeriodStartDate;
	}
	@JsonGetter("SUBSCRIPTION_PERIOD_END_DATE")
	public String getSubscriptionPeriodEndDate() {
		return DateFormatUtil.addOffset(subscriptionPeriodEndDate);
	}
	public void setSubscriptionPeriodEndDate(String subscriptionPeriodEndDate) {
		this.subscriptionPeriodEndDate = subscriptionPeriodEndDate;
	}
	@JsonGetter("SAP_CONTRACT_START_DATE")
	public String getSapContractStartDate() {
		return sapContractStartDate;
	}
	public void setSapContractStartDate(String sapContractStartDate) {
		this.sapContractStartDate = sapContractStartDate;
	}
	@JsonGetter("SAP_CONTRACT_END_DATE")
	public String getSapContractEndDate() {
		return sapContractEndDate;
	}
	public void setSapContractEndDate(String sapContractEndDate) {
		this.sapContractEndDate = sapContractEndDate;
	}
	@JsonGetter("FULFILLMENT_DATE")
	public String getFulfillmentDate() {
		return DateFormatUtil.addOffset(fulfillmentDate);
	}
	public void setFulfillmentDate(String fulfillmentDate) {
		this.fulfillmentDate = fulfillmentDate;
	}
	@JsonGetter("VAT_REGISTRATION_ID")
	public String getVatRegistrationId() {
		return vatRegistrationId;
	}
	public void setVatRegistrationId(String vatRegistrationId) {
		this.vatRegistrationId = vatRegistrationId;
	}
	@JsonGetter("VAT_RATE_APPLIED")
	public String getVatRateApplied() {
		return vatRateApplied;
	}
	public void setVatRateApplied(String vatRateApplied) {
		this.vatRateApplied = vatRateApplied;
	}
	@JsonGetter("TAX_CODE")
	public String getTaxCode() {
		return taxCode;
	}
	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}
	@JsonGetter("INVOICE_NUMBER")
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	@JsonGetter("IP_COUNTRY")
	public String getIpCountry() {
		return ipCountry;
	}
	public void setIpCountry(String ipCountry) {
		this.ipCountry = ipCountry;
	}
	@JsonGetter("LAST_MODIFIED_DATE")
	public String getLastModifiedDate() {
		return DateFormatUtil.addOffset(lastModifiedDate);
	}
	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	@JsonGetter("PROMO_SETUP_AMOUNT")
	public String getPromoSetupAmount() {
		return promoSetupAmount;
	}
	public void setPromoSetupAmount(String promoSetupAmount) {
		this.promoSetupAmount = promoSetupAmount;
	}
	@JsonGetter("PROMO_SETUP_UNIT")
	public String getPromoSetupUnit() {
		return promoSetupUnit;
	}
	public void setPromoSetupUnit(String promoSetupUnit) {
		this.promoSetupUnit = promoSetupUnit;
	}
	@JsonGetter("USAGE_TYPE")
	public String getUsageType() {
		return usageType;
	}
	public void setUsageType(String usageType) {
		this.usageType = usageType;
	}
	@JsonGetter("SUBSCRIPTION_PLAN_EXTERNAL_KEY")
	public String getSubscriptionPlanExternalKey() {
		return subscriptionPlanExternalKey;
	}
	public void setSubscriptionPlanExternalKey(String subscriptionPlanExternalKey) {
		this.subscriptionPlanExternalKey = subscriptionPlanExternalKey;
	}
	@JsonGetter("SUBSCRIPTION_PLAN_NAME")
	public String getSubscriptionPlanName() {
		return subscriptionPlanName;
	}
	public void setSubscriptionPlanName(String subscriptionPlanName) {
		this.subscriptionPlanName = subscriptionPlanName;
	}
	@Override
	public String toString() {
		return "FinanceReport [orderNo=" + orderNo + ", transactionId=" + transactionId + ", orderDate=" + orderDate
				+ ", customerName=" + customerName + ", o2Id=" + o2Id + ", productLineCode=" + productLineCode
				+ ", productId=" + productId + ", productName=" + productName + ", billingTerm=" + billingTerm
				+ ", subscriptionId=" + subscriptionId + ", quantity=" + quantity + ", listPrice=" + listPrice
				+ ", totalPrice=" + totalPrice + ", creditDaysDiscount=" + creditDaysDiscount + ", unitDiscount="
				+ unitDiscount + ", tax=" + tax + ", totalOrderPrice=" + totalOrderPrice + ", billToProvince="
				+ billToProvince + ", billToPostalCode=" + billToPostalCode + ", billToCountry=" + billToCountry
				+ ", saleType=" + saleType + ", orderStatus=" + orderStatus + ", currency=" + currency
				+ ", orderOrigin=" + orderOrigin + ", offeringType=" + offeringType + ", offeringDetailsName="
				+ offeringDetailsName + ", offeringDetailsExternalKey=" + offeringDetailsExternalKey + ", supportLevel="
				+ supportLevel + ", mediaType=" + mediaType + ", nextBilling_date=" + nextBilling_date
				+ ", extendedListPrice=" + extendedListPrice + ", extendedTotalDiscount=" + extendedTotalDiscount
				+ ", promoName=" + promoName + ", promoType=" + promoType + ", promoSubType=" + promoSubType
				+ ", shipToProvince=" + shipToProvince + ", shipToPostalCode=" + shipToPostalCode + ", shipToCountry="
				+ shipToCountry + ", paymentType=" + paymentType + ", psp=" + psp + ", store=" + store
				+ ", subscriptionPeriodStartDate=" + subscriptionPeriodStartDate + ", subscriptionPeriodEndDate="
				+ subscriptionPeriodEndDate + ", sapContractStartDate=" + sapContractStartDate + ", sapContractEndDate="
				+ sapContractEndDate + ", fulfillmentDate=" + fulfillmentDate + ", vatRegistrationId="
				+ vatRegistrationId + ", vatRateApplied=" + vatRateApplied + ", taxCode=" + taxCode + ", invoiceNumber="
				+ invoiceNumber + ", ipCountry=" + ipCountry + ", lastModifiedDate=" + lastModifiedDate
				+ ", promoSetupAmount=" + promoSetupAmount + ", promoSetupUnit=" + promoSetupUnit + ", usageType="
				+ usageType + ", subscriptionPlanExternalKey=" + subscriptionPlanExternalKey + ", subscriptionPlanName="
				+ subscriptionPlanName + "]";
	}

}
