package com.autodesk.data.stream.delivery;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.kinesisfirehose.model.BufferingHints;
import com.amazonaws.services.kinesisfirehose.model.DeliveryStreamDescription;
import com.amazonaws.services.kinesisfirehose.model.S3DestinationUpdate;
import com.amazonaws.services.kinesisfirehose.model.UpdateDestinationRequest;
import com.amazonaws.util.StringUtils;

/**
 * 
 * @author Surajit Paul
 * @May 18, 2017
 *
 */
public class FinanceReportStreamDelivery extends AbstractDataStreamDelivery {

	private static final Log LOG = LogFactory.getLog(FinanceReportStreamDelivery.class);

	// DeliveryStream properties
	private static String updateS3ObjectPrefix;
	private static Integer updateSizeInMBs;
	private static Integer updateIntervalInSeconds;
	private static final String CONFIG_FILE = "pelican.properties";


	/**
	 * Initialize the parameters.
	 *
	 * @throws Exception
	 */
	private static void init() throws Exception {
		// Load the parameters from properties file
		loadConfig();
		// Initialize the clients
		initClients();
	}

	/**
	 * Load the input parameters from properties file.
	 *
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private static void loadConfig() throws FileNotFoundException, IOException {
		try (InputStream configStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(CONFIG_FILE)) {
			if (configStream == null) {
				throw new FileNotFoundException();
			}
			properties = new Properties();
			properties.load(configStream);
		}

		// Read properties
		accountId = properties.getProperty("customerAccountId");
		createS3Bucket = Boolean.valueOf(properties.getProperty("createS3Bucket"));
		s3RegionName = properties.getProperty("s3RegionName");
		s3BucketName = properties.getProperty("s3BucketName").trim();
		s3BucketMetadata = properties.getProperty("s3BucketMetaData").trim();
		s3ObjectPrefix = properties.getProperty("s3ObjectPrefix").trim();
		LOG.info("s3ObjectPrefix: " + s3ObjectPrefix);

		String intervalInSecondsProperty = properties.getProperty("destinationIntervalInSeconds");
		s3DestinationIntervalInSeconds = StringUtils.isNullOrEmpty(intervalInSecondsProperty) ? null : Integer.parseInt(intervalInSecondsProperty.trim());

		deliveryStreamName = properties.getProperty("deliveryStreamName");
		firehoseRegion = properties.getProperty("firehoseRegion");
		iamRegion = properties.getProperty("iamRegion");

		enableUpdateDestination = Boolean.valueOf(properties.getProperty("updateDestination"));
		updateS3ObjectPrefix = properties.getProperty("updateS3ObjectPrefix").trim();
		LOG.info("updateS3ObjectPrefix: " + updateS3ObjectPrefix);
		String updateSizeInMBsProperty = properties.getProperty("updateSizeInMBs");
		updateSizeInMBs = StringUtils.isNullOrEmpty(updateSizeInMBsProperty) ? null : Integer.parseInt(updateSizeInMBsProperty.trim());
		String updateIntervalInSecondsProperty = properties.getProperty("updateIntervalInSeconds");
		updateIntervalInSeconds = StringUtils.isNullOrEmpty(updateIntervalInSecondsProperty) ? null : Integer.parseInt(updateIntervalInSecondsProperty.trim());
		vaultSpace = properties.getProperty("vaultSpace").trim();
		sourceHost = properties.getProperty("sourceHost").trim();
	}

	/**
	 * 
	 * @param args
	 * @throws Exception
	 */
	public void executeIngestion() throws Exception {
		init();
		try {
			int waitTimeSecs = s3DestinationIntervalInSeconds == null ? DEFAULT_WAIT_INTERVAL_FOR_DATA_DELIVERY_SECS : s3DestinationIntervalInSeconds;
			updateDeliveryStream();
			publishFinanceReportStream(s3BucketMetadata);
			waitTimeSecs = updateIntervalInSeconds == null ? waitTimeSecs : updateIntervalInSeconds;
			waitForDataDelivery(waitTimeSecs);
		} catch (AmazonServiceException ase) {
			LOG.error("Caught Amazon Service Exception");
			LOG.error("Status Code " + ase.getErrorCode());
			LOG.error("Message: " + ase.getErrorMessage(), ase);
		} catch (AmazonClientException ace) {
			LOG.error("Caught Amazon Client Exception");
			LOG.error("Exception Message " + ace.getMessage(), ace);
		}
	}



	/**
	 * Method to update s3 destination with updated s3Prefix, and buffering hints values.
	 *
	 * @throws Exception
	 */
	@SuppressWarnings("deprecation")
	private static void updateDeliveryStream() throws Exception {

		DeliveryStreamDescription deliveryStreamDescription = describeDeliveryStream(deliveryStreamName);

		LOG.info("Updating DeliveryStream Destination: " + deliveryStreamName + " with new configuration options");
		// get(0) -> DeliveryStream currently supports only one destination per DeliveryStream
		UpdateDestinationRequest updateDestinationRequest = 
				new UpdateDestinationRequest()
				.withDeliveryStreamName(deliveryStreamName)
				.withCurrentDeliveryStreamVersionId(deliveryStreamDescription.getVersionId())
				.withDestinationId(deliveryStreamDescription.getDestinations().get(0).getDestinationId());

		S3DestinationUpdate s3DestinationUpdate = new S3DestinationUpdate();
		s3DestinationUpdate.withPrefix(updateS3ObjectPrefix);

		BufferingHints bufferingHints = null;
		if (updateSizeInMBs != null || updateIntervalInSeconds != null) {
			bufferingHints = new BufferingHints();
			bufferingHints.setSizeInMBs(updateSizeInMBs);
			bufferingHints.setIntervalInSeconds(updateIntervalInSeconds);
		}
		s3DestinationUpdate.setBufferingHints(bufferingHints);
		updateDestinationRequest.setS3DestinationUpdate(s3DestinationUpdate);
		firehoseClient.updateDestination(updateDestinationRequest);
	}

	public static void main(String[] args) throws Exception{
		FinanceReportStreamDelivery streamDelivery = new FinanceReportStreamDelivery();
		streamDelivery.executeIngestion();
	}
}
