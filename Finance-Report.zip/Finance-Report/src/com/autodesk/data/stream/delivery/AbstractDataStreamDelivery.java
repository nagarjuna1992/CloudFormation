package com.autodesk.data.stream.delivery;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.amazonaws.regions.Region;
import com.amazonaws.regions.RegionUtils;
import com.amazonaws.services.identitymanagement.AmazonIdentityManagement;
import com.amazonaws.services.identitymanagement.AmazonIdentityManagementClient;
import com.amazonaws.services.kinesisfirehose.AmazonKinesisFirehoseClient;
import com.amazonaws.services.kinesisfirehose.model.DeliveryStreamDescription;
import com.amazonaws.services.kinesisfirehose.model.DescribeDeliveryStreamRequest;
import com.amazonaws.services.kinesisfirehose.model.DescribeDeliveryStreamResult;
import com.amazonaws.services.kinesisfirehose.model.PutRecordBatchRequest;
import com.amazonaws.services.kinesisfirehose.model.PutRecordBatchResult;
import com.amazonaws.services.kinesisfirehose.model.Record;
import com.amazonaws.services.s3.AmazonS3Client;
import com.autodesk.data.api.FinanceReportApiClient;
import com.autodesk.data.stream.security.MetadataUtil;
import com.autodesk.data.util.EncryptionUtil;
import com.autodesk.data.util.FinanceReportConstants;


/**
 * Abstract class that contains all the common methods used in samples for
 * Amazon S3 and Amazon Redshift destination.
 */
public abstract class AbstractDataStreamDelivery implements FinanceReportConstants {
	// S3 properties
	protected static AmazonS3Client s3Client;
	protected static boolean createS3Bucket;
	protected static String s3BucketName;
	protected static String s3BucketMetadata;
	protected static String s3ObjectPrefix;
	protected static String s3RegionName;
	protected static String sourceHost;

	// DeliveryStream properties
	protected static AmazonKinesisFirehoseClient firehoseClient;
	protected static String accountId;
	protected static String deliveryStreamName;
	protected static String firehoseRegion;
	protected static boolean enableUpdateDestination;

	// S3Destination Properties
	protected static Integer s3DestinationIntervalInSeconds;

	// Properties Reader
	protected static Properties properties;

	protected static String vaultSpace;
	private static final int BATCH_PUT_MAX_SIZE = 500;

	// Default wait interval for data to be delivered in specified destination.
	protected static final int DEFAULT_WAIT_INTERVAL_FOR_DATA_DELIVERY_SECS = 300;

	// IAM Role
	protected static String iamRegion;
	protected static AmazonIdentityManagement iamClient;

	// Logger
	private static final Log LOG = LogFactory.getLog(AbstractDataStreamDelivery.class);

	/**
	 * Method to initialize the clients using the specified AWSCredentials.
	 *
	 * @param Exception
	 */
	@SuppressWarnings("deprecation")
	protected static void initClients() throws Exception {
		// S3 client
		s3Client = new AmazonS3Client(); //credentials
		Region s3Region = RegionUtils.getRegion(s3RegionName);
		s3Client.setRegion(s3Region);

		// Firehose client
		//firehoseClient = new AmazonKinesisFirehoseClient(credentials);
		firehoseClient = new AmazonKinesisFirehoseClient();
		firehoseClient.setRegion(RegionUtils.getRegion(firehoseRegion));

		// IAM client
		iamClient = new AmazonIdentityManagementClient(); //credentials
		iamClient.setRegion(RegionUtils.getRegion(iamRegion));
	}

	/**
	 * Method to put records in the specified delivery stream by reading
	 * contents from sample input file using PutRecordBatch API.
	 *
	 * @throws IOException
	 */
	protected static void publishFinanceReportStream(String s3BucketMetadata) throws IOException {
		FinanceReportApiClient ingester = new FinanceReportApiClient();
		EncryptionUtil encrypt = new EncryptionUtil();
		List<Record> recordList = new ArrayList<Record>();
		MetadataUtil metaUtil = new MetadataUtil();
		Map<String, String> period = metaUtil.getFinanceReportPeriod(s3BucketMetadata);
		LOG.info("Period: " + period.toString());
		LOG.info("Vault Space: " + vaultSpace);
		LOG.info("S3 bucket: " + s3BucketName);
		int batchSize = 0;
		String token = period.get("TOKEN");
		try {
			token = encrypt.encrypt(token);
			LOG.info("Encrypted encoded vault token: " + token);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		BufferedReader reader = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(ingester.getData(sourceHost, vaultSpace, s3BucketName, period))));
		String line = null;
		while ((line = reader.readLine()) != null) {
			String data = line + "\n";
			Record record = createRecord(data);
			recordList.add(record);
			batchSize++;
			if (batchSize == BATCH_PUT_MAX_SIZE) {
				putRecordBatch(recordList);
				recordList.clear();
				batchSize = 0;
			}
		}
		if (batchSize > 0) {
			putRecordBatch(recordList);
		}
		metaUtil.writeFinanceReportCheckpoint(period.get(END), period.get(FREQUENCY), s3BucketMetadata, token);
	}




	/**
	 * Method to describe the delivery stream.
	 *
	 * @param deliveryStreamName the delivery stream
	 * @return the delivery description
	 */
	protected static DeliveryStreamDescription describeDeliveryStream(String deliveryStreamName) {
		DescribeDeliveryStreamRequest describeDeliveryStreamRequest = new DescribeDeliveryStreamRequest();
		describeDeliveryStreamRequest.withDeliveryStreamName(deliveryStreamName);
		DescribeDeliveryStreamResult describeDeliveryStreamResponse =
				firehoseClient.describeDeliveryStream(describeDeliveryStreamRequest);
		return describeDeliveryStreamResponse.getDeliveryStreamDescription();
	}

	/**
	 * Method to wait for the specified buffering interval seconds so that data
	 * will be delivered to corresponding destination.
	 *
	 * @param waitTimeSecs the buffering interval seconds to wait upon
	 * @throws InterruptedException
	 */
	protected static void waitForDataDelivery(int waitTimeSecs) throws InterruptedException {
		LOG.info("Since the Buffering Hints IntervalInSeconds parameter is specified as: " + waitTimeSecs
				+ " seconds. Waiting for " + waitTimeSecs + " seconds for the data to be written to S3 bucket");
		TimeUnit.SECONDS.sleep(waitTimeSecs);

		LOG.info("Data delivery to S3 bucket " + s3BucketName + " is complete");
	}

	/**
	 * Method to perform PutRecordBatch operation with the given record list.
	 *
	 * @param recordList the collection of records
	 * @return the output of PutRecordBatch
	 */
	private static PutRecordBatchResult putRecordBatch(List<Record> recordList) {
		System.out.println("Record size: " + recordList.size());
		PutRecordBatchRequest putRecordBatchRequest = new PutRecordBatchRequest();
		putRecordBatchRequest.setDeliveryStreamName(deliveryStreamName);
		putRecordBatchRequest.setRecords(recordList);
		return firehoseClient.putRecordBatch(putRecordBatchRequest);
	}


	/**
	 * Method to create the record object for given data.
	 *
	 * @param data the content data
	 * @return the Record object
	 */
	private static Record createRecord(String data) {
		return new Record().withData(ByteBuffer.wrap(data.getBytes()));
	}
}
