package com.autodesk.data.stream.delivery;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class KinesisPartitionDate {

	public static void main(String[] args) {
		LocalDateTime now = LocalDateTime.now();

        System.out.println("Before : " + now);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");

        String formatDateTime = now.format(formatter);

        System.out.println("After : " + formatDateTime);

	}

}
