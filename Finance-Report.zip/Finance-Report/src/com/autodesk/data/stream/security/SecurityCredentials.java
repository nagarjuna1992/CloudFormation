package com.autodesk.data.stream.security;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bettercloud.vault.Vault;
import com.bettercloud.vault.VaultConfig;
import com.bettercloud.vault.VaultException;

/**
 * 
 * @author Surajit Paul
 * @Jun 20, 2017
 *
 */
public class SecurityCredentials {


	private static final Log LOG = LogFactory.getLog(SecurityCredentials.class);
	Map<String, String> securityCredentials = new HashMap<String, String>();

	/**
	 * Fetches security credentials from Vault storage
	 * @return
	 */
	public Map<String, String> getSecurityConfig(String token, String vaultSpace) {

		try {
			VaultConfig config = new VaultConfig("https://vault.aws.autodesk.com", token); 
			final Vault vault = new Vault(config);
			vault.auth().renewSelf();
			securityCredentials = vault
					.logical()
					.read("eis/" + vaultSpace + "/generic/metadata/finance_report_pelican").getData();
		} catch (VaultException e) {
			e.printStackTrace();
		}		

		LOG.info(securityCredentials.toString());
		return securityCredentials;
	}
}
