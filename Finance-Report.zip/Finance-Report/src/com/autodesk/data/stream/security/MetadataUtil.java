package com.autodesk.data.stream.security;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.amazonaws.regions.Region;
import com.amazonaws.regions.RegionUtils;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.model.S3Object;
import com.autodesk.data.util.EncryptionUtil;
import com.autodesk.data.util.FinanceReportConstants;
import com.google.gson.Gson;

/**
 * 
 * @author Surajit Paul
 * @Jun 20, 2017
 *
 */
public class MetadataUtil implements FinanceReportConstants {
	
	private static final Log LOG = LogFactory.getLog(MetadataUtil.class);
	/**
	 * 
	 * @param s3bucket
	 * @return
	 */
	public Map<String, String> getFinanceReportPeriod(String s3bucket){
		EncryptionUtil encryption = new EncryptionUtil();
		Map<String, String> period = new HashMap<String, String>();
		String val = this.readFinanceReportCheckpoint(s3bucket);
		System.out.println(val);
		Gson gson = new Gson();
		@SuppressWarnings("unchecked")
		Map<String, String> financeReportMetadata = gson.fromJson(val, Map.class);
		System.out.println("Finance report: " + financeReportMetadata.toString());
		String checkpoint = financeReportMetadata.get("CHECKPOINT");
		String frequency = financeReportMetadata.get("FREQUENCY");
		String token = financeReportMetadata.get("TOKEN");
		try {
			token = encryption.decrypt(token);
			System.out.println("Vault token: " + token);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Checkpoint: " + checkpoint);
		
		DateTimeFormatter formatter =
                DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
		LocalDateTime date = LocalDateTime.parse(checkpoint, formatter);
		System.out.println("Date: " + date.toString());
		LocalDateTime startTime = date.minusMinutes(5);
		System.out.println("Start Time: " + startTime.toString());
		LocalDateTime endTime = date.plusHours(Integer.parseInt(frequency));
		System.out.println("End Time: " + endTime.toString());
		LocalDateTime now = LocalDateTime.now();
		System.out.println("Current Time: " + now.toString());
		if(endTime.isAfter(now)){
			System.out.println("End time is after current time: " + true);
			endTime = now;
		}
		System.out.println("End Time: " + endTime.toString());
		String startTimeText = startTime.format(formatter);
		System.out.println("Start Time formatted: " + startTimeText.toString());
		String endTimeText = endTime.format(formatter);
		System.out.println("End Time formatted: " + endTimeText.toString());
		period.put("START", startTimeText);
		period.put("END", endTimeText);
		period.put("FREQUENCY", frequency);
		period.put("TOKEN", token);
		return period;
	}
	
	/**
	 * 
	 * @param s3bucket
	 * @return
	 */
	public String readFinanceReportCheckpoint(String s3bucket){
		AmazonS3 client = getAmazonClient();
		StringBuffer input = new StringBuffer();
		String currentLine = null;
		S3Object object = client.getObject(new GetObjectRequest(s3bucket, METADATA_S3_PREFIX));
		BufferedReader br = new BufferedReader(new InputStreamReader(object.getObjectContent()));
		try {
			while((currentLine = br.readLine()) != null){
				input.append(currentLine);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return input.toString();	
	}
	
	/**
	 * Write Pelican Finance Report checkpoint to s3 bucket
	 */
	public void writeFinanceReportCheckpoint(String checkpoint, String frequency, String s3Bucket, String token){
		Gson gson = new Gson();
		AmazonS3 client = getAmazonClient();
		Map<String, String> keyValue = new HashMap<String, String>();
		keyValue.put("CHECKPOINT", checkpoint);
		keyValue.put("FREQUENCY", frequency);
		keyValue.put("TOKEN", token);
		String dataset = gson.toJson(keyValue); 
		ObjectMetadata omd = new ObjectMetadata();
		omd.setContentType("application/text");
		byte[] dataByte = dataset.toString().getBytes(StandardCharsets.UTF_8);
		ByteArrayInputStream output = new ByteArrayInputStream(dataByte);
		omd.setContentLength(dataByte.length);			
		PutObjectRequest poreq = new PutObjectRequest(s3Bucket, METADATA_S3_PREFIX, output, omd);
		poreq.getRequestClientOptions().setReadLimit(256);
		PutObjectResult por = client.putObject(poreq);
		LOG.info("Put object result - " + por.toString());
		
	}
		
	/**
	 * S3 client
	 * @return
	 */
	@SuppressWarnings("deprecation")
	public AmazonS3 getAmazonClient(){
		AmazonS3 s3Client = new AmazonS3Client(); //credentials
		Region s3Region = RegionUtils.getRegion("us-west-1");
		s3Client.setRegion(s3Region);
		return s3Client;
	}
}

