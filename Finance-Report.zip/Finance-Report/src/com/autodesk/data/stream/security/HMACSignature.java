
package com.autodesk.data.stream.security;

import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TimeZone;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
/**
 * 
 * @author Surajit Paul
 * @May 17, 2017
 *
 */
public class HMACSignature {
	
    public static Map<String, String> generateSignature(String HMACINSTANCE, String SECRETKEY, String APPFAMILYID, String PARTNERID) {
        LinkedHashMap<String, String> signature = new LinkedHashMap<String, String>();
        try {
            Mac mac = Mac.getInstance(HMACINSTANCE);
            String secret = SECRETKEY;
            SecretKeySpec keySpec = new SecretKeySpec(secret.getBytes(), HMACINSTANCE);
            mac.init(keySpec);
            String appFamilyId = APPFAMILYID;
            String partnerId = PARTNERID;
            Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
            String timestamp = String.valueOf(cal.getTimeInMillis() / 1000);
            signature.put("TIMESTAMP", timestamp);
            String message = String.valueOf(partnerId) + appFamilyId + timestamp;
            byte[] signatureBytes = mac.doFinal(message.getBytes(StandardCharsets.UTF_8));
            signature.put("SIGN", HexUtil.encode(signatureBytes));
            System.out.println("Signature: " + signature);
        }
        catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        catch (InvalidKeyException e) {
            e.printStackTrace();
        }
        return signature;
    }
}