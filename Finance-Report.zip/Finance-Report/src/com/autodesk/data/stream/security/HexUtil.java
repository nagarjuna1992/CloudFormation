
package com.autodesk.data.stream.security;

/**
 * 
 * @author Surajit Paul
 * @May 16, 2017
 *
 */
public class HexUtil {
    public static String encode(String sourceText) {
        return HexUtil.encode(sourceText.getBytes());
    }

    public static String encode(byte[] rawData) {
        StringBuilder hexText = new StringBuilder();
        String initialHex = null;
        int initHexLength = 0;
        int i = 0;
        while (i < rawData.length) {
            int positiveValue = rawData[i] & 255;
            initialHex = Integer.toHexString(positiveValue);
            initHexLength = initialHex.length();
            while (initHexLength++ < 2) {
                hexText.append("0");
            }
            hexText.append(initialHex);
            ++i;
        }
        return hexText.toString();
    }

    /**
     * Encode input byte
     * @param rawData
     * @return
     */
    public static String encode(byte rawData) {
        StringBuilder hexText = new StringBuilder();
        String initialHex = null;
        int initHexLength = 0;
        int positiveValue = rawData & 255;
        initialHex = Integer.toHexString(positiveValue);
        initHexLength = initialHex.length();
        while (initHexLength++ < 2) {
            hexText.append("0");
        }
        hexText.append(initialHex);
        return hexText.toString();
    }

    /**
     * Decode input string
     * @param hexText
     * @return
     */
    public static String decodeToString(String hexText) {
        byte[] rawToByte = HexUtil.decodeToByte(hexText);
        return new String(rawToByte);
    }

    /**
     * Decode input string to byte array
     * @param hexText
     * @return
     */
    public static byte[] decodeToByte(String hexText) {
        String chunk = null;
        if (hexText != null && hexText.length() > 0) {
            int numBytes = hexText.length() / 2;
            byte[] rawToByte = new byte[numBytes];
            int offset = 0;
            int i = 0;
            while (i < numBytes) {
                chunk = hexText.substring(offset, offset + 2);
                offset += 2;
                rawToByte[i] = (byte)(Integer.parseInt(chunk, 16) & 255);
                ++i;
            }
            return rawToByte;
        }
        return null;
    }
}