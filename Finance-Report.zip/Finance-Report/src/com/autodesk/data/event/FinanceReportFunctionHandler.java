package com.autodesk.data.event;

import java.io.InputStream;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.autodesk.data.stream.delivery.FinanceReportStreamDelivery;

/**
 * Lambda function handler to trigger finance report ingestion process
 * @author Surajit Paul
 * @Jun 20, 2017
 *
 */
public class FinanceReportFunctionHandler implements RequestHandler<InputStream, Object> {

    @Override
    public Object handleRequest(InputStream input, Context context) {
    	LambdaLogger log = context.getLogger();
    	FinanceReportStreamDelivery streamDelivery = new FinanceReportStreamDelivery();
        log.log("Input: " + input);
        log.log("Function name: " + context.getFunctionName());
        log.log("Memory Limit [MB]: " + context.getMemoryLimitInMB());
        log.log("AWS Request Id: " + context.getAwsRequestId());
        log.log("Client Context: " + context.getClientContext());
        log.log("Identity: " + context.getIdentity());

        String output = "Hello, " + input + "!";
        
        try {
			streamDelivery.executeIngestion();
		} catch (Exception e) {
			e.printStackTrace();
		}
        
        return output;
    }

}
