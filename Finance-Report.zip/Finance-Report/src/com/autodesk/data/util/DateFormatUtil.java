package com.autodesk.data.util;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

/**
 * 
 * @author Surajit Paul
 * @Jun 21, 2017
 *
 */
public class DateFormatUtil {

	/**
	 * Date format standardization
	 * @param inputDate
	 * @return
	 */
	public static String addOffset(String inputDate){
		System.out.println("Input date: " + inputDate);
		DateTimeFormatter inputFormatter = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm:ss");
		if(inputDate == null || "".equals(inputDate)){
			return "1970-01-01 00:00:00+00:00";
		}
		DateTime dateValue = DateTime.parse(inputDate, inputFormatter);		
		DateTimeFormatter fmt = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ssZZ");
		String outputDate = fmt.withZone(DateTimeZone.UTC).print(dateValue);
		return outputDate;
	}
}
