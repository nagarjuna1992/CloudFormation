/**
 *  Copyright (c) 2015 by Autodesk, Inc. All rights reserved.
 *
 *  The information contained herein is confidential and proprietary to
 *  Autodesk, Inc., and considered a trade secret as defined under civil
 *  and criminal statutes.  Autodesk shall pursue its civil and criminal
 *  remedies in the event of unauthorized use or misappropriation of its
 *  trade secrets.  Use of this information by anyone other than authorized
 *  employees of Autodesk, Inc. is granted only under a written non-
 *  disclosure agreement, expressly prescribing the scope and manner of
 *  such use.
 */
package com.autodesk.data.util;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.Charsets;
import org.apache.commons.codec.binary.Base64;

/**
 * Encryption utility class to support encryption/decryption of sensitive data
 * @author Surajit Paul
 * @version v1.0
 * @since 01.28.2016
 *
 */
public class EncryptionUtil implements FinanceReportConstants {
	
	/**
	 * 
	 * @param plainText
	 * @return
	 * @throws Exception
	 */
	public String encrypt(String plainText) throws Exception {
		Cipher cipher = getCipher(Cipher.ENCRYPT_MODE);
		byte[] encryptedBytes = cipher.doFinal(plainText.getBytes(Charsets.UTF_8));
		return Base64.encodeBase64String(encryptedBytes);
	}

	/**
	 * 
	 * @param encrypted
	 * @return
	 * @throws Exception
	 */
	public String decrypt(String encrypted) throws Exception {
		Cipher cipher = getCipher(Cipher.DECRYPT_MODE);
		byte[] plainBytes = cipher.doFinal(Base64.decodeBase64(encrypted));
		return new String(plainBytes);
	}

	/**
	 * 
	 * @param cipherMode
	 * @return
	 * @throws Exception
	 */
	private Cipher getCipher(int cipherMode) throws Exception {		
		SecretKeySpec keySpecification = new SecretKeySpec(encryptionKey.getBytes("UTF-8"), ENCRYPTION_ALGORITHM);
		Cipher cipher = Cipher.getInstance(ENCRYPTION_ALGORITHM);
		cipher.init(cipherMode, keySpecification);
		return cipher;
	}
}
