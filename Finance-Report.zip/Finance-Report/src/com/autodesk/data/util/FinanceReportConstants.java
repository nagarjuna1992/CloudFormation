/**
 *  Copyright (c) 2015 by Autodesk, Inc. All rights reserved.
 *
 *  The information contained herein is confidential and proprietary to
 *  Autodesk, Inc., and considered a trade secret as defined under civil
 *  and criminal statutes.  Autodesk shall pursue its civil and criminal
 *  remedies in the event of unauthorized use or misappropriation of its
 *  trade secrets.  Use of this information by anyone other than authorized
 *  employees of Autodesk, Inc. is granted only under a written non-
 *  disclosure agreement, expressly prescribing the scope and manner of
 *  such use.
 */
package com.autodesk.data.util;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

/**
 * Interface containing all message parsers and EFS constants
 */
public interface FinanceReportConstants {	
	
	public static final Charset UTF8 = StandardCharsets.UTF_8;
	public static final String HMAC = "HMAC_INSTANCE";
	public static final String SECRET_KEY = "PELICAN_SECRET_KEY"; 
	public static final String APP_FAMILY = "APP_FAMILY_ID";
	public static final String PARTNER_ID = "PARTNER_ID";
	public static final String START = "START";
	public static final String END = "END";
	public static final String FREQUENCY = "FREQUENCY";
	
	public static final String ENCRYPTION_ALGORITHM = "AES";
	public final String encryptionKey = "MZyg7ewksCpRrfO9";
	public final String METADATA_S3_PREFIX = "ingest/metadata/finance_report_pelican/finance_report_pelican.dat";
	
}
