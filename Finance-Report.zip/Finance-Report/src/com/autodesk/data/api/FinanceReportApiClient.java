package com.autodesk.data.api;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpEntity;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;

import com.autodesk.data.stream.dto.FinanceReport;
import com.autodesk.data.stream.security.HMACSignature;
import com.autodesk.data.stream.security.SecurityCredentials;
import com.autodesk.data.util.FinanceReportConstants;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.opencsv.CSVParser;
import com.opencsv.CSVReader;
import com.opencsv.bean.ColumnPositionMappingStrategy;
import com.opencsv.bean.CsvToBean;

/**
 * 
 * @author Surajit Paul
 * @May 18, 2017
 *
 */
public class FinanceReportApiClient implements FinanceReportConstants {
	
	private static final Log LOG = LogFactory.getLog(FinanceReportApiClient.class);
	
	/**
     * 
     * orderEndDate.strftime("%m/%d/%Y %H:%M:%S")
     * @param Args
     */
    public byte[] getData(String host, String vaultSpace, String s3bucket, Map<String, String> period) {
    	SecurityCredentials cred = new SecurityCredentials();
    	Map<String, String> credentials = cred.getSecurityConfig(period.get("TOKEN"), vaultSpace);
    	String orderStartDate = null;
    	String orderEndDate = null;
    	
    	LOG.info("Credentials from Vault: " + credentials.toString());
    	
    	String hmacInstance = credentials.get(HMAC);
    	String secretKey = credentials.get(SECRET_KEY);
    	String appFamilyId = credentials.get(APP_FAMILY);
    	String partnerId = credentials.get(PARTNER_ID);
    	StringBuffer content = new StringBuffer();
    	// STG: pelican-reports-stg.aws.autodesk.com (external)
    	// PRD: pelican-reports.autodesk.com (internal)
    	String financeReportUrl = "https://" + host + "/tfel2rs/v2/reports/finance"; // Lambda function
    	
        try {
            ArrayList<String> value = new ArrayList<String>();
            orderStartDate = period.get(START);
            System.out.println(orderStartDate);
            orderEndDate = period.get(END);
            System.out.println(orderEndDate);
            Map <String,String>signature = HMACSignature.generateSignature(hmacInstance, secretKey, appFamilyId, partnerId);
            
            System.out.println("HMAC signature: " + signature);

            for (String x : signature.values()) {
                value.add(x);
            }
            System.out.println(orderEndDate.split(" ")[0].replace("/", ""));
            String urlString = financeReportUrl;
            CloseableHttpClient client = HttpClients.createDefault();
            HttpPost post = new HttpPost(urlString);
            post.setHeader("X-E2-HMAC-Signature", (String)value.get(1));
            post.setHeader("X-E2-HMAC-Timestamp", (String)value.get(0));
            post.setHeader("X-E2-PartnerId", partnerId);
            post.setHeader("X-E2-AppFamilyId", appFamilyId);
            ArrayList<BasicNameValuePair> urlParameters = new ArrayList<BasicNameValuePair>();
            urlParameters.add(new BasicNameValuePair("lastModifiedStartDate", orderStartDate));
            urlParameters.add(new BasicNameValuePair("lastModifiedEndDate", orderEndDate));
            post.setEntity((HttpEntity)new UrlEncodedFormEntity(urlParameters));
            CloseableHttpResponse response = client.execute((HttpUriRequest)post);
            System.out.println("\nSending 'POST' request to URL : " + urlString);
            System.out.println("Post parameters : " + (Object)post.getEntity());
            if (response.getStatusLine().getStatusCode() != 200) {
                System.out.println("Bad Request,hence exiting");
                System.out.println("Response Code : " + response.getStatusLine().getStatusCode());
                System.exit(1);
            } else {
                List<FinanceReport> list = new LinkedList<FinanceReport>();
                System.out.println("Starting write process in a file");
                
                CSVReader reader = null;
        		reader = new CSVReader(new BufferedReader(new InputStreamReader(response.getEntity().getContent())), 
        				CSVParser.DEFAULT_SEPARATOR, 
        				CSVParser.DEFAULT_QUOTE_CHARACTER, false);
        		ColumnPositionMappingStrategy<FinanceReport> strat = new ColumnPositionMappingStrategy<FinanceReport>();
        		strat.setType(FinanceReport.class);
        		String[] columns = new String[] {"orderNo", "transactionId", "orderDate", "customerName", "o2Id", "productLineCode"
        				, "productId", "productName", "billingTerm", "subscriptionId", "quantity", "listPrice", "totalPrice"
        				, "creditDaysDiscount", "unitDiscount", "tax", "totalOrderPrice", "billToProvince", "billToPostalCode"
        				, "billToCountry", "saleType", "orderStatus", "currency", "orderOrigin", "offeringType", "offeringDetailsName"
        				, "offeringDetailsExternalKey", "supportLevel", "mediaType", "nextBilling_date", "extendedListPrice", "extendedTotalDiscount"
        				, "promoName", "promoType", "promoSubType", "shipToProvince", "shipToPostalCode", "shipToCountry", "paymentType"
        				, "psp", "store", "subscriptionPeriodStartDate", "subscriptionPeriodEndDate", "sapContractStartDate", "sapContractEndDate"
        				, "fulfillmentDate", "vatRegistrationId", "vatRateApplied", "taxCode", "invoiceNumber", "ipCountry", "lastModifiedDate"
        				, "promoSetupAmount", "promoSetupUnit", "usageType", "subscriptionPlanExternalKey", "subscriptionPlanName"}; 		
        		strat.setColumnMapping(columns);
        		CsvToBean<FinanceReport> csv = new CsvToBean<FinanceReport>();
        		list = csv.parse(strat, reader);
        		
        		Predicate<FinanceReport> reportPredicate = p-> p.getOrderNo().equalsIgnoreCase("Order No");
        		list.removeIf(reportPredicate);
        		
        		ObjectMapper mapper = new ObjectMapper();	
        		
        		String json;
        		try {
        			json = mapper.writeValueAsString(list);
        			JsonNode jsonNode = mapper.readTree(json);			
        			if (jsonNode.isArray()) {
        				ArrayNode arrayNode = (ArrayNode) jsonNode;
        				for (int i = 0; i < arrayNode.size(); i++) {
        					if(i >= 1){
        						content.append("\n");
        					}
        					JsonNode individualElement = arrayNode.get(i);
        					content.append(individualElement.toString());		                
        				}
        			}
        		} catch (IOException e) {				
        			e.printStackTrace();
        		}
        		
        		System.out.println("Finance report: " + content.toString());
            }
        }
        catch (IOException e) {
            System.out.println(e);
            System.exit(1);
        }   
        String dataset = content.toString(); 
		return dataset.getBytes(UTF8);
    }
}
