package com.autodesk.data.api;

import com.autodesk.data.stream.delivery.FinanceReportStreamDelivery;

public class PelicanFinanceReportIngestion {

	public static void main(String[] args) {
		FinanceReportStreamDelivery streamDelivery = new FinanceReportStreamDelivery();
        try {
			streamDelivery.executeIngestion();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}


